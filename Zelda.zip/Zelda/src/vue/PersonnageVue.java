package vue;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import modele.Ennemi;
import modele.Joueur;


public class PersonnageVue {

    protected Ennemi ennemi;
    protected Image imagePerso;
    protected ImageView imageViewPerso;

    public PersonnageVue(Ennemi ennemi, Image imagePerso) {
        this.ennemi=ennemi;
        this.imagePerso= imagePerso;
        this.imageViewPerso= new ImageView(imagePerso);
    }

    public ImageView getImage() {
        return this.imageViewPerso;
    }
}

package vue;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import modele.Ennemi;
import modele.Joueur;


public class PersonnageVue {

    protected Ennemi perso;
    protected Image imagePerso;
    protected ImageView imageViewPerso;

    public PersonnageVue(Ennemi perso, Image imagePerso) {
        this.perso=perso;
        this.imagePerso= imagePerso;
        this.imageViewPerso= new ImageView(imagePerso);
    }

    public ImageView getImage() {
        return this.imageViewPerso;
    }
}

package modele;

/*
 * Archer.java
 * Classe de création des Archers, ennemi spécial qui ne se déplace pas et attaque à distance  l'aide de projectiles
 */

public class Archer extends Ennemi {

	public Archer() {
		
		super(15, 0, false);
		
	}
	
	public void attaque() {
		
		//TODO Lance un projectile dans la direction du joueur, animation à prévoir.
		
	}

}

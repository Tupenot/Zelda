package modele;

public class BossTerre extends Ennemi {
    public BossTerre() {
        super(150,10,false);
    }
}

package modele;

public class Epee extends Arme {
	
	public Epee() {
		super(5);
	}

}

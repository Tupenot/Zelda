package modele;

public class Hache extends Arme{

	public Hache() {
		super(15);
	}
}

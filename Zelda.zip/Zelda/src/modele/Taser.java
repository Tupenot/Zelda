package modele;

public class Taser extends Arme{
	
	private int tpsImmobile;//temps pendant lequel l'ennemi est immobilisé
	public Taser() {
		super(0);
		this.setTpsImmobile(3);
	}
	public int getTpsImmobile() {
		return tpsImmobile;
	}
	public void setTpsImmobile(int tpsImmobile) {
		this.tpsImmobile = tpsImmobile;
	}
	
}

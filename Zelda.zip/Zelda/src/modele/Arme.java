package modele;
public class Arme {

	private int ptsAttaque;
	
	public Arme (int ptsAttaque) {
		this.ptsAttaque=ptsAttaque;
	}
	
	public int getPtsAttaque() {
		return this.ptsAttaque;
	}
	
}

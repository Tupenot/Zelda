package modele;

/*
 * Joueur.java
 * Classe de création d'un objet Joueur, intéragit avec les différents objets et Ennemis.
 */

public class Joueur {

	private int pdv;
	private int vitesse;
	private String nom;
	
	public Joueur(String n) {
		
		this.setNom(n);
		this.setPdv(25);
		this.setVitesse(1);
		
	}

	public int getPdv() {
		return pdv;
	}

	public void setPdv(int pdv) {
		this.pdv = pdv;
	}

	public int getVitesse() {
		return vitesse;
	}

	public void setVitesse(int vitesse) {
		this.vitesse = vitesse;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}
	
	public void prendDegats() {
		
		//TODO Repousser le joueur quand il se prend un coup, animation à prévoir.
		
	}
	
	public void prendObjet() {
		
		//TODO Prendre un objet avec le joueur en le touchant, animation à prévoir.
		
	}


	
}

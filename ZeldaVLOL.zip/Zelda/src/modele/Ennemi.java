package modele;

/*
 * Ennemi.java
 * 
 */

import javafx.beans.property.IntegerProperty;

public class Ennemi {

	private int pdv;
	private int vitesse;
	private boolean deplacement;
	//private Arme arme;
	
	public Ennemi(int p, int v, boolean d) {
		
		this.setPdv(p);
		this.setVitesse(v);
		this.setDeplacement(d);
		//this.arme = a;
		
	}

	public int getPdv() {
		return pdv;
	}

	public void setPdv(int pdv) {
		this.pdv = pdv;
	}

	public int getVitesse() {
		return vitesse;
	}

	public void setVitesse(int vitesse) {
		this.vitesse = vitesse;
	}

	public boolean isDeplacement() {
		return deplacement;
	}

	public void setDeplacement(boolean deplacement) {
		this.deplacement = deplacement;
	}
	
	public void attaque(Joueur cible) {
		
		//cible.setPdv(cible.getPdv() - this.Arme.getDegats);
		
	}
	
}

package modele;

public class Bombe extends Arme{
	private int porte; //distance parcourus par la bombe
	public Bombe() {
		super(15);
		this.setPorte(3);
	}
	public int getPorte() {
		return porte;
	}
	public void setPorte(int porte) {
		this.porte = porte;
	}

}

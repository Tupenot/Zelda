package modele;

public class Marteau extends Arme{

	public Marteau() {
		super(10);
	}
}

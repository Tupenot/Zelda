package game.model.objects;

public class Objects {

	private String name;
		
	public Objects(String n) {
		this.name=n;
	}
		
	public String getName() {
		return this.name;
	}
}

package game.model.objects;

public class Shield extends Objects {
	
	public Shield(String name) {
		super ("Shield");
	}

}

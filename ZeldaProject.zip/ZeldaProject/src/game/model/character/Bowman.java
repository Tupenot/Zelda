package game.model.character;

import game.model.teardrop.Bow;
import game.model.teardrop.Teardrop;

public class Bowman extends Enemy {
	 static Teardrop bow = new Bow ("Bow", 0.25, 4);

	public Bowman() {
		super ("Archer", 15, 0, bow);
	}

	public void attack() {
	}
}

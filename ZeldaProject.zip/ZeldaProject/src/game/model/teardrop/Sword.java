package game.model.teardrop;

public class Sword extends Teardrop {

	public Sword(String name, double attack) {
		super(name, attack);
	}
}

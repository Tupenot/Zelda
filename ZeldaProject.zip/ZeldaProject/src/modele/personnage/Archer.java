/*package modele.personnage;

import modele.arme.Arc;
import modele.arme.Arme;

public class Archer extends Ennemi {
	 static Arme arc = new Arc ("Arc", 0.25, 4);

	public Archer() {
		super ("Archer", 15, 0, arc);
	}

	@Override
	public void attaquer() {		
	}
}*/

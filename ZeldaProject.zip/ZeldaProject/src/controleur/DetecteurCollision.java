package controleur;
public class DetecteurCollision {

	private int[][] map;
	
	public DetecteurCollision(int[][] map) {
		this.map=map;
	}

	public boolean testCollisionHaut(int posY, int posX, int posXMax) {
		if((map[(posY/32)][(posX/32)]!=0) || map[(posY/32)][(posXMax/32)]!=-1) {
			return true;
		}
		return false;
	}
	
	public boolean testCollisionBas(int posYMax, int posX, int posXMax) {
		if((map[(posYMax/32)][(posX/32)]!=0) || map[(posYMax/32)][(posXMax/32)]!=-1) {
			return true;
		}
		return false;
	}
	
	public boolean testCollisionDroit(int posY, int posXMax, int posYMax) {
		if((map[(posY/32)][(posXMax/32)]!=0) || map[(posYMax/32)][(posXMax/32)]!=-1) {
			return true;
		}
		return false;
	}
	
	public boolean testCollisionGauche(int posY, int posX, int posYMax) {
		if((map[(posY/32)][(posX/32)]!=0) || map[(posYMax/32)][(posX/32)]!=-1) {
			return true;
		}
		return false;
	}
}

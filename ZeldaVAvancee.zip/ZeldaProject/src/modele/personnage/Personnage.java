package modele.personnage;


import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.Image.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import modele.personnage.Deplacement;
import modele.arme.Arme;
import javafx.fxml.FXML;



public abstract class Personnage {

	private double pv;
	private String nom;
	private double coeur;
	protected double armure;
	private Arme arme;
	private Deplacement deplacement;
	private double degats;
	public Personnage(String nom, double pv, double armure, Arme arme, Deplacement deplacement) {
		this.setNom(nom);
		this.setpv(pv);
		this.setArmure(armure);
		this.deplacement = deplacement;
		if (arme == null) {
			this.degats = 0.1;
		}
		else {
			this.degats = arme.getAttaque();
		}	
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}
	
	public Deplacement getDeplacement() {
		return this.deplacement;
	}

	public double getpv() {
		return this.pv;
	}
	
	public void setpv(double pv) {
		this.pv = pv;
	}
	
	public void perdrepv() {
		this.pv = pv-1;
	}
	
	public void recevoirdegats(int degats) {
		this.pv = pv - degats;
	}
	
	public void recupererpv(double rpv) {
		this.pv = pv + rpv;
	}
	
	public double getArmure() {
		return armure;
	}

	public void setArmure(double armure) {
		this.armure = armure;
	}
	
	public Arme getArme() {
		return arme;
	}
	
	public void setArme (Arme arme) {
		this.arme = arme;
	}

	public void attaquer(Personnage p1, Arme a1) {
		double degats = a1.getAttaque();
		p1.defendre(degats);
	}

	public void defendre(double degats) {
		if (armureTrue()) {
			if (this.armure <= degats) {
				degats -= this.armure;
				this.armure = 0;
				this.coeur -= degats;
			}

			else {
				this.armure -= degats;
			}
		}

		else {
			this.coeur -= degats;
		}
	}

	public boolean armureTrue() {
		boolean armureActive = false;
		
		return armureActive ;
	}
	
	public void ramasserArme(Arme arme) {
		this.arme = null;
		this.arme = arme;
	}
	
}

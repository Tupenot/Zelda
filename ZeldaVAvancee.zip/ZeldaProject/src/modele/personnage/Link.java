package modele.personnage;

import java.util.ArrayList;

import controleur.DetecteurCollisionPersonnage;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import modele.arme.Arme;
import modele.arme.Epee;
import modele.objets.Objets;

public class Link extends Personnage {

		
		private ArrayList<Objets> inventaire;
		private ArrayList<Arme> armes;
		private DetecteurCollisionPersonnage coll;
		static Arme epee = new Epee ("Epée",1);
		
		public Link(Deplacement d, DetecteurCollisionPersonnage c) {
			super("Link",3,3,epee, d);
			this.inventaire= new ArrayList<Objets>();
			this.armes = new ArrayList<Arme>();
			this.coll=c;
		}
				
		/*public void ramasserArme(Arme arme, Ennemi ennemi) {
			this.epee = arme;
		}*/
		
		public void activerArmure(KeyEvent event) {
			if (event.getCode() == KeyCode.TAB) {
				this.armure = 3;
			}
			
			else if ((event.getCode() == KeyCode.TAB)) {
				this.armure = 5;
			}
		}
}

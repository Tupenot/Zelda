package modele.objets;

public class Bouclier extends Objets {
	
	public Bouclier(String nom) {
		super (nom);
	}

}

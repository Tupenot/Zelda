package modele.maps;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;

public class Terrain {

	private int[][] map;
	private String fichmap;


	public Terrain(String fileName) {
		fichmap=fileName;
		map = new int[32][32];
	}

	public void initMap() {
		File fichier = new File(fichmap);
		String ligne = "";
		BufferedReader lecteurFichier;
		try {
			lecteurFichier = new BufferedReader(new FileReader(fichier));
			int i = 0;
			StringTokenizer st=new StringTokenizer(ligne, ", ");
			do {
				int j = 0;
				try {
					ligne = lecteurFichier.readLine();
				} catch (IOException e) {
					e.printStackTrace();
				}
				if(ligne!=null){ 
					st = new StringTokenizer(ligne, ", ");
					while(st.hasMoreTokens()) {

						map[i][j] = Integer.parseInt(st.nextToken(", "));
						j++;
					}
					System.out.println(ligne);
					i++;
				}
			}while(ligne != null);
			try {
				lecteurFichier.close();
			} catch (IOException e) {
				System.out.println("Impossible de lire le fichier");
			}
		} catch (FileNotFoundException e) {
			System.out.println("Le fichier n'a pas été trouvé");
		}
	}

	public int[][] getMap() {
		return map;
	}
	


	public void updateMap() {

	}
}	 


package controleur;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import modele.maps.Terrain;
import modele.personnage.Deplacement;
import modele.personnage.Link;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.TilePane;
import javafx.util.Duration;

public class Controleur implements Initializable {
	
	private Image im = new Image("/ressources/Maison.png");
    private ImageView imw = new ImageView(im);
	private Link link;
    private DetecteurCollisionPersonnage collisionperso;
    
	@FXML
    private TilePane tilePaneFX;
	private ImageView Joueur;
	
	// Haut
		File image_link_haut = new File("src/ressources/joueur_H.png");
	    Image link_haut = new Image(image_link_haut.toURI().toString());
	    
	    // Gauche
	    File image_link_gauche = new File("src/ressources/joueur_G.png");
	    Image link_gauche = new Image(image_link_gauche.toURI().toString());
	    
	    // Droite
	    File image_link_droite = new File("src/ressources/joueur_D.png");
	    Image link_droite = new Image(image_link_droite.toURI().toString());
	    
	    // Bas 
	    File image_link_bas = new File("src/ressources/joueur_B.png");
	    Image link_bas = new Image(image_link_bas.toURI().toString());
	
	public void initialize(URL location, ResourceBundle resources) {
		// Création de la première map
		Terrain maison = new Terrain("src/modele/maps/mapmaison.txt");
		maison.initMap();
		int[][] mapmaison = maison.getMap();        
		tilePaneFX.getChildren().add(imw);
		//Deplacement l = new Deplacement(new Case(16,16), mapmaison);
		//link = new Link(l,collisionperso);
		//Joueur.translateXProperty().bind(link.getDeplacement().getPosX());
		//Joueur.translateYProperty().bind(link.getDeplacement().getPosY());
		Joueur.setImage(link_bas);
        Joueur.setLayoutX(220);
        Joueur.setLayoutY(176);
        Joueur.setFocusTraversable(true);

	}	
	
	public void deplacement(KeyEvent event) {
		
		if (event.getCode() == KeyCode.UP || event.getCode() == KeyCode.Z) {
                Joueur.setLayoutY(Joueur.getLayoutY() - 16);
                Joueur.setImage(link_haut);
            
        }

        if (event.getCode() == KeyCode.DOWN || event.getCode() == KeyCode.S) {
            
        	Joueur.setLayoutY(Joueur.getLayoutY() + 16);
        	Joueur.setImage(link_bas);
        }

        if ((event.getCode() == KeyCode.LEFT || event.getCode() == KeyCode.Q)) {
           
        	Joueur.setLayoutX(Joueur.getLayoutX() - 16);
        	Joueur.setImage(link_gauche);

        }

        if ((event.getCode() == KeyCode.RIGHT || event.getCode() == KeyCode.D)) {
           
        	Joueur.setLayoutX(Joueur.getLayoutX() + 16);
        	Joueur.setImage(link_droite);
        }
	}	
}

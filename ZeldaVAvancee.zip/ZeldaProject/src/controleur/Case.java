package controleur;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;

public class Case {
		
		private  IntegerProperty x;
		private IntegerProperty y;
		
		public Case(int x, int y) {
			this.x = new SimpleIntegerProperty();
			this.y = new SimpleIntegerProperty();
			this.x.set(x);
			this.y.set(y);
		}

		public int getX() {
			return this.x.get();
		}

		public int getY() {
			return this.y.get();
		}
		public IntegerProperty getXProperty() {
			return this.x;
		}

		public IntegerProperty getYProperty() {
			return this.y;
		}

		public void setX(int x0) {
			this.x.set(x0);;
		}

		public void setY(int y0) {
			this.y.set(y0);;
		}
}
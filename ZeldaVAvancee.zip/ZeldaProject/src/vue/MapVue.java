package vue;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class MapVue {
	 private int[][] map;
	    private int[][] mapvillage;
	    private int[][] plaine;
	    private int[][] cfeu;
	    private int[][] cglace;
	    private int[][] cterre;
	    private int[][] sdjfeu;
	    private int[][] bossfeu;
	    private int[][] sdjterre;
	    private int[][] bossterre;
	    private int[][] sdjglace;
	    private int[][] bossglace;
	    private Image im = new Image("/ressources/Maison.png");
	    private ImageView imw = new ImageView(im);
	    private Image imvill = new Image("/ressources/Village.png");
	    private ImageView imwvill = new ImageView(imvill);
	    private Image implaine = new Image("/ressources/plaine.png");
	    private ImageView imwplaine = new ImageView(implaine);
	    private Image imcfeu = new Image("/ressources/Cfeu.png");
	    private ImageView imwcfeu = new ImageView(imcfeu);
	    private Image imcglace = new Image("/ressources/Cglace.png");
	    private ImageView imwcglace = new ImageView(imcglace);
	    private Image imcterre = new Image("/ressources/Cterre.png");
	    private ImageView imwcterre = new ImageView(imcterre);
	    private Image imdjfeu = new Image("/ressources/sdfeu.png");
	    private ImageView imwdjfeu = new ImageView(imdjfeu);
	    private Image imbossfeu = new Image("/ressources/bossfeu.png");
	    private ImageView imwbossfeu = new ImageView(imbossfeu);
	    private Image imdjterre = new Image("/ressources/sdterre.png");
	    private ImageView imwdjterre = new ImageView(imdjterre);
	    private Image imbossterre = new Image("/ressources/bossterre.png");
	    private ImageView imwbossterre = new ImageView(imbossterre);
	    private Image imdjglace = new Image("/ressources/sdglace.png");
	    private ImageView imwdjglace = new ImageView(imdjglace);
	    private Image imbossglace = new Image("/ressources/bossglace.png");
	    private ImageView imwbossglace = new ImageView(imbossglace);
}

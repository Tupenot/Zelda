package modele.personnage;

import modele.arme.Arme;
import java.util.ArrayList;
import javafx.scene.input.KeyCode;

import javafx.scene.input.KeyEvent;

public class Joueur extends Personnage {
	
	private ArrayList<Arme> liste;
	private Arme arme;
	
	public Joueur(String nom, double coeur, double armure, Arme arme) {
		super("Link", coeur, armure, arme);
		this.liste = new ArrayList<Arme>();
	}
	
	public void ramasserArme(Arme arme) {
		this.arme = null;
		this.arme = arme;
	}
	
	public void activerArmure(KeyEvent event) {
		if (event.getCode() == KeyCode.TAB) {
			this.armure = 3;
		}
		
		else if ((event.getCode() == KeyCode.TAB) && (/* Récompense donnant l'armure choisie */)) {
			this.armure = 5;
		}
	}
}

package modele.arme;

public class Epee extends Arme {

	public Epee(String nom, double attaque) {
		super(nom, attaque);
	}
}

package modele.arme;

public class Arc extends Arme {

	private int portee;
	
	public Arc(String nom, double attaque) {
		super(nom, attaque);
	}
	
	public Arc(String nom, double attaque, int portee) {
		super(nom, attaque);
		this.setPortee(portee);
	}

	public int getPortee() {
		return portee;
	}

	public void setPortee(int portee) {
		this.portee = portee;
	}
}

package modele.arme;

public class Arme {
	
	private String nom;
	private double attaque;
	
	public Arme (String nom, double attaque) {
		this.setNom(nom);
		this.setAttaque(attaque);
	}
	
	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public double getAttaque() {
		return attaque;
	}

	public void setAttaque(double attaque) {
		this.attaque = attaque;
	}
	public String toString() {
		return this.nom + " et " + this.attaque;
	}
}

package modele.personnage;

import modele.arme.Arme;
import java.util.ArrayList;
import javafx.scene.input.KeyCode;

import javafx.scene.input.KeyEvent;

public class Joueur extends Personnage {
	
	private ArrayList<Arme> liste;
	private Arme arme;
	
	public Joueur(String nom, double coeur, double armure, Arme arme) {
		super("Link", coeur, armure, arme);
		this.setListe(new ArrayList<Arme>());
	}
	
	public void ramasserArme(Arme arme) {
		this.arme = null;
		this.arme = arme;
	}
	
	public void activerArmure(KeyEvent event) {
		if (event.getCode() == KeyCode.TAB) {
			this.armure = 3;
		}
		
		else if ((event.getCode() == KeyCode.TAB) &&  (armureTrue())) {
			this.armure = 5;
		}
	}

	public ArrayList<Arme> getListe() {
		return liste;
	}
	public Joueur(String nom, double coeur, double armure, Arme arme,ArrayList<Arme> liste) {
		super("Link", coeur, armure, arme);
		setListe(liste);
		getListe();
		
	}

	public void setListe(ArrayList<Arme> liste) {
		liste.add(arme);
		this.liste = liste;
	}
	
}

package modele.personnage;


import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.Image.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import modele.arme.Arme;
import controleur.Controleur;
import javafx.fxml.FXML;



public abstract class Personnage {

	private String nom;
	private double coeur;
	protected double armure;
	private Arme arme;
	public Personnage(String nom, double coeur, double armure, Arme arme) {
		this.setNom(nom);
		this.setCoeur(coeur);
		this.setArmure(armure);
		this.arme = arme;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public double getCoeur() {
		return coeur;
	}

	public void setCoeur(double coeur) {
		this.coeur = coeur;
	}

	public double getArmure() {
		return armure;
	}

	public void setArmure(double armure) {
		this.armure = armure;
	}

	public void attaquer(Personnage p1, Arme a1) {
		double degats = a1.getAttaque();
		p1.defendre(degats);
	}

	public void defendre(double degats) {
		if (armureTrue()) {
			if (this.armure <= degats) {
				degats -= this.armure;
				this.armure = 0;
				this.coeur -= degats;
			}

			else {
				this.armure -= degats;
			}
		}

		else {
			this.coeur -= degats;
		}
	}

	public boolean armureTrue() {
		boolean armureActive;
		if (this.armure > 0) {
			armureActive=true;
		}
		else {
			armureActive=false;
		}
		
		return armureActive;
	}
	public String toString() {
		
		return this.nom + " il te reste " + this.coeur + " pv, " + this.armure + " armure et ton arme actuelle est : " + this.arme.toString();
	
	}
}

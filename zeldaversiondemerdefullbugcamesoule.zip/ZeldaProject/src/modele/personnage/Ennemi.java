/*package modele.personnage;

import modele.arme.Arme;

public abstract class Ennemi extends Personnage {

	public Ennemi(String nom, double coeur, double armure, Arme arme) {
		super(nom, coeur, armure, arme);
	}
	
	public abstract void attaquer ();
}*/

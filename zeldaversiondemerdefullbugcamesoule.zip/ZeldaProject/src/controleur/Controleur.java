package controleur;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import com.sun.javafx.collections.MappingChange.Map;

import modele.maps.Terrain;
import modele.personnage.Link;
import vue.MapVue;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.TilePane;
import javafx.util.Duration;

public class Controleur implements Initializable {

	MapVue mv = new MapVue();
	Terrain maison = new Terrain("src/modele/maps/mapmaison.csv");
	int[][] mapmaison = maison.getMap(); 
	Terrain village = new Terrain("src/modele/maps/mapvillage.csv");
	int[][] mapvillage = village.getMap();
	Terrain plaine = new Terrain("src/modele/maps/mapplaine.csv");
	int[][] mapplaine = plaine.getMap();
	
	// Initialisation des images de Link //
	
	// Haut
	File image_link_haut = new File("src/ressources/joueur_H.png");
	Image link_haut = new Image(image_link_haut.toURI().toString());

	// Gauche
	File image_link_gauche = new File("src/ressources/joueur_G.png");
	Image link_gauche = new Image(image_link_gauche.toURI().toString());

	// Droite
	File image_link_droite = new File("src/ressources/joueur_D.png");
	Image link_droite = new Image(image_link_droite.toURI().toString());

	// Bas 
	File image_link_bas = new File("src/ressources/joueur_B.png");
	Image link_bas = new Image(image_link_bas.toURI().toString());
	
	////////////////////////////////////////
	
	@FXML
	private TilePane tilePaneFX;
	@FXML
	private ImageView joueur;
	private Link link;


	public void deplacement(KeyEvent event) {

		if ((event.getCode() == KeyCode.UP || event.getCode() == KeyCode.Z)) {
			if (mapmaison[((int) joueur.getLayoutY() / 16) - 1][(int) (joueur.getLayoutX() / 16)] == -1) {
				joueur.setLayoutY(joueur.getLayoutY() - 8);
				joueur.setImage(link_haut);
			} else if (mapvillage[((int) joueur.getLayoutY() / 16) - 1][(int) (joueur.getLayoutX() / 16)] == -1) {
				joueur.setLayoutY(joueur.getLayoutY() - 8);
				joueur.setImage(link_haut);
			} else if (mapplaine[((int) joueur.getLayoutY() / 16) - 1][(int) (joueur.getLayoutX() / 16)] == -1) {
				joueur.setLayoutY(joueur.getLayoutY() - 8);
				joueur.setImage(link_haut);
			} else if (mapvillage[((int) joueur.getLayoutY() / 16) - 1][(int) (joueur.getLayoutX() / 16)] == 210000) {
				joueur.setLayoutY(joueur.getLayoutY() - 8);
				joueur.setImage(link_haut);
			}	
		}

		if ((event.getCode() == KeyCode.DOWN || event.getCode() == KeyCode.S)) {
			if (mapvillage[((int) joueur.getLayoutY() / 16) + 1][(int) (joueur.getLayoutX() / 16)] == -1) {
				joueur.setLayoutY(joueur.getLayoutY() + 8);
				joueur.setImage(link_bas);
			} else if (mapplaine[((int) joueur.getLayoutY() / 16) + 1][(int) (joueur.getLayoutX() / 16)] == -1) {
				joueur.setLayoutY(joueur.getLayoutY() + 8);
				joueur.setImage(link_bas);
			} else if (mapmaison[((int) joueur.getLayoutY() / 16) + 1][(int) (joueur.getLayoutX() / 16)] == 200000) {
				joueur.setLayoutY(joueur.getLayoutY() + 8);
				joueur.setImage(link_bas);
			} else if (mapmaison[((int) joueur.getLayoutY() / 16) + 1][(int) (joueur.getLayoutX() / 16)] == -1) {
				joueur.setLayoutY(joueur.getLayoutY() + 8);
				joueur.setImage(link_bas);
			}	
		}

		if ((event.getCode() == KeyCode.LEFT || event.getCode() == KeyCode.Q)) {
			if (mapmaison[(int) (joueur.getLayoutY() / 16)][((int) (joueur.getLayoutX() / 16)) - 1] == -1) {
				joueur.setLayoutX(joueur.getLayoutX() - 8);
				joueur.setImage(link_gauche);
			} else if (mapvillage[(int) (joueur.getLayoutY() / 16)][((int) (joueur.getLayoutX() / 16)) - 1] == -1) {
				joueur.setLayoutX(joueur.getLayoutX() - 8);
				joueur.setImage(link_gauche);
			} else if (mapplaine[((int) joueur.getLayoutY() / 16)][(int) (joueur.getLayoutX() / 16) - 1] == 230000) {
				joueur.setLayoutX(joueur.getLayoutX() - 8);
				joueur.setImage(link_gauche);
			} else if (mapplaine[(int) (joueur.getLayoutY() / 16)][((int) (joueur.getLayoutX() / 16)) - 1] == -1) {
				joueur.setLayoutX(joueur.getLayoutX() - 8);
				joueur.setImage(link_gauche);
			}	
		}

		if ((event.getCode() == KeyCode.RIGHT || event.getCode() == KeyCode.D)) {
			if (mapvillage[(int) (joueur.getLayoutY() / 16)][((int) (joueur.getLayoutX() / 16)) + 1] == -1) {
				joueur.setLayoutX(joueur.getLayoutX() + 8);
				joueur.setImage(link_droite);
			} else if (mapplaine[(int) (joueur.getLayoutY() / 16)][((int) (joueur.getLayoutX() / 16)) + 1] == -1) {
				joueur.setLayoutX(joueur.getLayoutX() + 8);
				joueur.setImage(link_droite);
			} else if (mapvillage[((int) joueur.getLayoutY() / 16)][(int) (joueur.getLayoutX() / 16) + 1] == 220000) {
				joueur.setLayoutX(joueur.getLayoutX() + 8);
				joueur.setImage(link_droite);
			} else if (mapmaison[(int) (joueur.getLayoutY() / 16)][((int) (joueur.getLayoutX() / 16)) + 1] == -1) {
				joueur.setLayoutX(joueur.getLayoutX() + 8);
				joueur.setImage(link_droite);
			}	
		}
		
		if (mapmaison[((int) joueur.getLayoutY() / 16)][(int) (joueur.getLayoutX() / 16)] == 200000) {
            village.initMap();
            tilePaneFX.getChildren().remove(mv.maison());
            tilePaneFX.getChildren().add(mv.village());
            joueur.setLayoutX(272);
            joueur.setLayoutY(336);
            joueur.setImage(link_bas);
        }
		
		if (mapvillage[((int) joueur.getLayoutY() / 16)][(int) (joueur.getLayoutX() / 16)] == 210000) {
			maison.initMap();
            tilePaneFX.getChildren().remove(mv.village());
            tilePaneFX.getChildren().add(mv.maison());
            joueur.setLayoutX(240);
            joueur.setLayoutY(464);
            joueur.setImage(new Image("/ressources/joueur_H.png"));
        }
		
		if (mapvillage[((int) joueur.getLayoutY() / 16)][(int) (joueur.getLayoutX() / 16)] == 220000) {
			plaine.initMap();
            tilePaneFX.getChildren().remove(mv.village());
            tilePaneFX.getChildren().add(mv.plaine());
            joueur.setLayoutX(16);
            joueur.setLayoutY(322);
            joueur.setImage(new Image("/ressources/joueur_D.png"));
        }

		
		if (mapplaine[((int) joueur.getLayoutY() / 16)][(int) (joueur.getLayoutX() / 16)] == 230000) {
			village.initMap();
            tilePaneFX.getChildren().remove(mv.plaine());
            tilePaneFX.getChildren().add(mv.village());
            joueur.setLayoutX(656);
            joueur.setLayoutY(176);
            joueur.setImage(new Image("/ressources/joueur_G.png"));
        }
		
		System.out.println("Identifiant de case (1) : " + mapvillage[(int) (joueur.getLayoutY() / 16)][(int) (joueur.getLayoutX() / 16)] +
                " | Coordonnées :  " + (int) joueur.getLayoutY() / 16 + " (Hauteur, Largeur) " + (int) joueur.getLayoutX() / 16);
	}
		
	
	public void initialize(URL location, ResourceBundle resources) {
		// Création de la première map     
		maison.initMap();
		tilePaneFX.getChildren().add(mv.maison());
		joueur.setImage(link_bas);
		joueur.setLayoutX(220);
		joueur.setLayoutY(176);
		joueur.setFocusTraversable(true);

	}	

		
}

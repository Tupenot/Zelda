package controleur;
public class DetecteurCollision {

	private int[][] map;
	
	public DetecteurCollision(int[][] map) {
		this.map=map;
	}

	public boolean testCollisionHaut(int posY, int posX, int posXMax) {
		if((map[(posY/16)][(posX/16)]!=0) || map[(posY/16)][(posXMax/16)]!=-1) {
			return true;
		}
		return false;
	}
	
	public boolean testCollisionBas(int posYMax, int posX, int posXMax) {
		if((map[(posYMax/16)][(posX/16)]!=0) || map[(posYMax/16)][(posXMax/16)]!=-1) {
			return true;
		}
		return false;
	}
	
	public boolean testCollisionDroit(int posY, int posXMax, int posYMax) {
		if((map[(posY/16)][(posXMax/16)]!=0) || map[(posYMax/16)][(posXMax/16)]!=-1) {
			return true;
		}
		return false;
	}
	
	public boolean testCollisionGauche(int posY, int posX, int posYMax) {
		if((map[(posY/16)][(posX/16)]!=0) || map[(posYMax/16)][(posX/16)]!=-1) {
			return true;
		}
		return false;
	}
}

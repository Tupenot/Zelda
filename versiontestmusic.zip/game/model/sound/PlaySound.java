package game.model.sound;


import java.io.File;
import java.io.IOException;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
public class PlaySound
{
	private Clip m_clip;
	public PlaySound(File clipFile)
	{
		AudioInputStream audioInputStream = null;
		try
		{
			audioInputStream = AudioSystem.getAudioInputStream(clipFile);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		if (audioInputStream != null)
		{
			AudioFormat format = audioInputStream.getFormat();
			DataLine.Info info = new DataLine.Info(Clip.class, format);
			try
			{
				m_clip = (Clip)AudioSystem.getLine(info);
				m_clip.open(audioInputStream);
			}
			catch (LineUnavailableException e)
			{
				e.printStackTrace();
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
		else
		{
			System.out.println("ClipPlayer.<init>(): can't get data from file " + clipFile.getName());
		}
	}
	public void play()
	{
		m_clip.setFramePosition(0);
		m_clip.loop(0);
	}
	public void stop()
	{
		m_clip.stop();
	}
	
	public static void main(String[] args) {
		try {
            PlaySound wp = new PlaySound(new File("src/game/resources/sounds/chuteLink.wav"));
            wp.play();           
        System.out.println("debug0");
   	 } catch (Exception e) {
            e.printStackTrace();
        }

	}
}
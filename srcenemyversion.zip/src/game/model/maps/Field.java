package game.model.maps;

import java.io.*;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Field {

    private int[][] map;
    private String filemap;


    public Field(String fileName) {
        filemap = fileName;
        map = new int[readX(filemap)][readY(filemap)];
    }

    public void initMap() {
        File file = new File(filemap);
        String line = "";
        BufferedReader br;
        try {
            br = new BufferedReader(new FileReader(file));
            int i = 0;
            StringTokenizer st = new StringTokenizer(line, ", ");
            do {
                int j = 0;
                try {
                    line = br.readLine();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (line != null) {
                    st = new StringTokenizer(line, ", ");
                    while (st.hasMoreTokens()) {
                        map[i][j] = Integer.parseInt(st.nextToken(", "));
                        j++;
                    }
                    // System.out.println(line);
                    i++;
                }
            } while (line != null);

            try {
                br.close();
            } catch (IOException e) {
                System.out.println("Error : Could not open file");
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error : Could not found file");
        }

        System.out.println(filemap + " has been loaded correctly");
    }

    public int[][] getMap() {
        return map;
    }

    public int readX(String fileName) {
        BufferedReader inputStream = null;
        int x = 0;
        try {
            inputStream = new BufferedReader(new FileReader(filemap));
            String length = inputStream.readLine();
            System.out.println("The value X recovered or parameterized is : " + length);
            x = Integer.parseInt(length);
        } catch (FileNotFoundException e) {
            //On gére cette exception si new FileReader("fichier.txt") a échoué
            System.out.println("Error : Could not open file");
        } catch (IOException e) {
            //On gère cette exception si inputStream.readLine() a échoué
            System.out.println("Error : Can not read the first line");
        }
        return x;
    }

    public int readY(String fileName) {
        BufferedReader inputStream = null;
        int y = 0;
        try {
            Scanner scanner = new Scanner(new File(fileName));
            String height = null;
            height = scanner.next();
            height = scanner.next();
            System.out.println("The value Y recovered or parameterized is : " + height);
            y = Integer.parseInt(height);
        } catch (FileNotFoundException e) {
            System.out.println("Error : Could not open file");
        }
        return y;
    }
}

package game.controller;

import game.model.character.Link;
import game.model.maps.Field;
import game.vue.maps.ViewMap;
import game.vue.player.ViewPlayer;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.TilePane;

import java.awt.event.KeyAdapter;
import java.net.URL;
import java.util.ResourceBundle;

public class Taskmaster implements Initializable {

    // private Field town = new Field("src/game/model/maps/mapvillage.csv");
    // private int[][] mapvillage = town.getMap();
    private boolean leavegameescape = false;
    private boolean leavegamey = false;
    private ViewMap mv = new ViewMap();
    private ViewPlayer pv = new ViewPlayer();
    private int[][] mapbuff;
    private Field house = new Field("src/game/model/maps/housemap.csv");
    private int[][] housemap = house.getMap();
    @FXML
    private TilePane tilePaneFX;
    @FXML
    private ImageView player;
    private Link link;


    public void movement(KeyEvent event) {

        if ((event.getCode() == KeyCode.UP || event.getCode() == KeyCode.Z)) {
            if (mapbuff[((int) player.getLayoutY() / 16) - 1][(int) (player.getLayoutX() / 16)] == -1
                    || (mapbuff[((int) player.getLayoutY() / 16) - 1][(int) (player.getLayoutX() / 16)] == 210000)
                    || (mapbuff[((int) player.getLayoutY() / 16) - 1][(int) (player.getLayoutX() / 16)] == 240)) {
                player.setLayoutY(player.getLayoutY() - 16);
                player.setImage(pv.up());
            }
        }

        if ((event.getCode() == KeyCode.DOWN || event.getCode() == KeyCode.S)) {
            if (mapbuff[((int) player.getLayoutY() / 16) + 1][(int) (player.getLayoutX() / 16)] == -1
                    || (mapbuff[((int) player.getLayoutY() / 16) + 1][(int) (player.getLayoutX() / 16)] == 200000)
                    || (mapbuff[((int) player.getLayoutY() / 16) + 1][(int) (player.getLayoutX() / 16)] == 280)) {
                player.setLayoutY(player.getLayoutY() + 16);
                player.setImage(pv.down());
            }
        }

        if ((event.getCode() == KeyCode.LEFT || event.getCode() == KeyCode.Q)) {
            if (mapbuff[(int) (player.getLayoutY() / 16)][((int) (player.getLayoutX() / 16)) - 1] == -1
                    || (mapbuff[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16) - 1] == 230)) {
                player.setLayoutX(player.getLayoutX() - 16);
                player.setImage(pv.left());
            }
        }

        if ((event.getCode() == KeyCode.RIGHT || event.getCode() == KeyCode.D)) {
            if (mapbuff[(int) (player.getLayoutY() / 16)][((int) (player.getLayoutX() / 16)) + 1] == -1
                    || (mapbuff[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16) + 1] == 220000)
                    || (mapbuff[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16) + 1] == 260)) {
                player.setLayoutX(player.getLayoutX() + 16);
                player.setImage(pv.right());
            }
        }

        if ((!(event.getCode() == KeyCode.Y)) && ((!(event.getCode() == KeyCode.ESCAPE))) && ((!(event.getCode() == KeyCode.N)))) {
            System.err.println("[!] Identifier of movement : " + mapbuff[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16)] + " [!] " + "\n-----------------------------------");
        }

        if (housemap[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16)] == 200000) {
            System.err.println("[!] Warning, you have changed map [!]" + "\n[!] Loading house to town [!]" + "\n[!] Identifier of the map change box : " + housemap[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16)] + " [!] ");

            tilePaneFX.getChildren().remove(mv.house());
            tilePaneFX.getChildren().add(mv.town());
            player.setLayoutX(272);
            player.setLayoutY(336);
            player.setImage(pv.down());

            //town.initMap();
            // copyField(mapvillage);
			/*for (int i=0; i<mapbuff.length;i++) {
				for(int j=0; j< mapbuff[i].length;j++) {
					System.out.print("----"+mapbuff[i][j]);
				}
				System.out.println();
			}*/

        }

		/*if (mapvillage[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16)] == 210000) {
			System.err.println("Changement town vers house : " + mapvillage[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16)]);

			tilePaneFX.getChildren().remove(mv.town());
			tilePaneFX.getChildren().add(mv.house());
			player.setLayoutX(240);
			player.setLayoutY(464);
			player.setImage(link_haut);
			
			house.initMap();
			copyField(housemap);
			for (int i=0; i<mapbuff.length;i++) {
				for(int j=0; j< mapbuff[i].length;j++) {
					System.out.print("----"+mapbuff[i][j]);
				}
				System.out.println();
			}

		
		}

		if (mapvillage[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16)] == 220000) {
			System.err.println("Changement town vers plain : " + mapvillage[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16)]);

			tilePaneFX.getChildren().remove(mv.town());
			tilePaneFX.getChildren().add(mv.plain());
			player.setLayoutX(16);
			player.setLayoutY(322);
			player.setImage(link_droite);
			
			plain.initMap();
			copyField(mapplaine);
			
			for (int i=0; i<mapbuff.length;i++) {
				for(int j=0; j< mapbuff[i].length;j++) {
					System.out.print("----"+mapbuff[i][j]);
				}
				System.out.println();
			}

		    plain.readX("src/game.model/maps/mapplaine.csv");
            plain.readY("src/game.model/maps/mapplaine.csv");



        } */

		/*if (mapplaine[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16)] == 230) {
			System.err.println("Changement plain vers town : " + mapplaine[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16)]);

			tilePaneFX.getChildren().remove(mv.plain());
			tilePaneFX.getChildren().add(mv.town());
			player.setLayoutX(656);
			player.setLayoutY(176);
			player.setImage(link_gauche);
			 
			// town.initMap();
			// copyField(mapvillage);
			for (int i=0; i<mapbuff.length;i++) {
				for(int j=0; j< mapbuff[i].length;j++) {
					System.out.print("----"+mapbuff[i][j]);
				}
				System.out.println();
			}

		
		}

		if (mapplaine[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16)] == 240) {
			System.err.println("Changement plain vers chemin de glace : " + mapplaine[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16)]);

			tilePaneFX.getChildren().remove(mv.plain());
			tilePaneFX.getChildren().add(mv.iceway());
			player.setLayoutX(400);
			player.setLayoutY(560);
			player.setImage(link_haut);
			
			iceway.initMap();
			copyField(mapcheminglace);
			for (int i=0; i<mapbuff.length;i++) {
				for(int j=0; j< mapbuff[i].length;j++) {
					System.out.print("----"+mapbuff[i][j]);
				}
				System.out.println();
			}

		

		}
		
		if (mapplaine[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16)] == 260) {
			System.err.println("Changement plain vers chemin de terre : " + mapplaine[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16)]);

			tilePaneFX.getChildren().remove(mv.plain());
			tilePaneFX.getChildren().add(mv.dirtway());
			player.setLayoutX(32);
            player.setLayoutY(176);
			player.setImage(link_droite);
			 
			dirtway.initMap();
			copyField(mapcheminterre);
			for (int i=0; i<mapbuff.length;i++) {
				for(int j=0; j< mapbuff[i].length;j++) {
					System.out.print("----"+mapbuff[i][j]);
				}
				System.out.println();
			}

		

		}
		
		if (mapplaine[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16)] == 280) {
			System.err.println("Changement plain vers chemin de feu : " + mapplaine[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16)]);

			tilePaneFX.getChildren().remove(mv.plain());
			tilePaneFX.getChildren().add(mv.fireway());
			player.setLayoutX(272);
            player.setLayoutY(16);
			player.setImage(link_bas);
			
			fireway.initMap();
			copyField(mapcheminfeu);
			for (int i=0; i<mapbuff.length;i++) {
				for(int j=0; j< mapbuff[i].length;j++) {
					System.out.print("----"+mapbuff[i][j]);
				}
				System.out.println();
			}

		

		}
		
        if (map[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16)] == 20) {
            changementmap1 = false;
            changementmap2 = false;
            changementmap3 = false;
            changementmap4 = false;
            changementmap5 = false;
            changementmap6 = true;
            tilePaneFX.getChildren().remove(imwcfeu);
            tilePaneFX.getChildren().add(imwdjfeu);
            player.setLayoutX(400);
            player.setLayoutY(432);
            player.setImage(new Image("/game.resources/joueur_H.png"));
        }
        

*/
		// Leave the game with KeyEvent //

        if (event.getCode() == KeyCode.ESCAPE && leavegamey) {
            leavegameescape = false;
        }

        if (event.getCode() == KeyCode.ESCAPE && !leavegamey) {
            leavegameescape = true;
            System.err.println("[!] You will leave the game, are you sure (y/n) ? [!]");
        }

        if (event.getCode() == KeyCode.Y && leavegameescape) {
            leavegamey = true;
        }

        if (event.getCode() == KeyCode.Y && !leavegameescape) {
            leavegamey = false;
        }

        if (event.getCode() == KeyCode.N) {
            leavegameescape = false;
            leavegamey = false;
        }

        if ((leavegameescape && leavegamey)) {
            System.err.println("[!] See you soon [!]");
            System.exit(0);
        }
    }



    public void copyField(int[][] source) {
        mapbuff = new int[source.length][source[0].length];
        for (int i = 0; i < source.length; i++) {
            for (int j = 0; j < source[i].length; j++) {
                mapbuff[i][j] = source[i][j];
            }
        }
        System.out.println("Length of the loaded map : " + source.length + "\nHeight of the loaded map : " + source[0].length);
    }

    public void initialize(URL location, ResourceBundle resources) {
        house.initMap();
        copyField(housemap);
        tilePaneFX.getChildren().add(mv.house());
        player.setImage(pv.down());
        player.setLayoutX(220);
        player.setLayoutY(176);
        player.setFocusTraversable(true);
        for (int i = 0; i < mapbuff.length; i++) {
            for (int j = 0; j < mapbuff[i].length; j++) {
                System.out.print(mapbuff[i][j] + ",");
            }
            System.out.println();
        }
    }
}

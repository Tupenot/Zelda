package game.vue.enemy;

import javafx.scene.image.Image;

import java.io.File;

public interface ViewEnemy {
	
	public Image up();
	
	public Image down();
	
	public Image left();
	
	public Image right();
}

package game.model.character;

import game.model.teardrop.Teardrop;

public class Enemy extends Character {

	public Enemy(String name, double heart, double armor, Teardrop teardrop) {
		super(name, heart, armor, teardrop);
	}
}

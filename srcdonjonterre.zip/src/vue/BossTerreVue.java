package vue;
import javafx.scene.image.Image;
import modele.BossTerre;
import modele.Joueur;

public class BossTerreVue extends PersonnageVue {

    public BossTerreVue(BossTerre b1) {
        super(b1, new Image("ressources/boss-terre1.png"));
    }

}

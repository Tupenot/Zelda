package game.controller;

import game.model.character.Bowman;
import game.model.character.Link;
import game.model.character.Character;
import game.model.maps.Field;
import game.model.teardrop.Sword;
import game.model.teardrop.Teardrop;
import game.vue.enemy.ViewEnemy;
import game.vue.enemy.ViewNormalBokoblinSword;
import game.vue.maps.ViewMap;
import game.vue.player.ViewPlayer;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.TilePane;

import java.net.URL;
import java.util.ResourceBundle;

public class Taskmaster implements Initializable {

    private Teardrop sword = new Teardrop ("sword",5);

    private Character link = new Link("",3,3,sword);
   private Character bokoblinsword = new Bowman ();

    // Leave condition
    private boolean leavegameescape = false;
    private boolean leavegamey = false;

    // Views
    private ViewMap mv = new ViewMap();
    private ViewPlayer pv = new ViewPlayer();
    private ViewEnemy ve = new ViewNormalBokoblinSword();

    // Game map
    private int[][] mapbuff;

    // Fields
    private Field house = new Field("src/game/model/maps/other/housemap.csv");
    private Field town = new Field("src/game/model/maps/other/town.csv");
    private Field plain = new Field("src/game/model/maps/other/plain.csv");
    private Field fireway = new Field("src/game/model/maps/fire/fireway.csv");
    private Field iceway = new Field("src/game/model/maps/ice/iceway.csv");
    private Field dirtway = new Field("src/game/model/maps/dirt/dirtway.csv");

    // Characters & Enemys


    @FXML
    private TilePane tilePaneFX;
    @FXML
    private ImageView player;
    @FXML
    private ImageView bokoblin;


    public void movement(KeyEvent event) {

        if ((event.getCode() == KeyCode.UP || event.getCode() == KeyCode.Z)) {
            if (mapbuff[((int) player.getLayoutY() / 16) - 1][(int) (player.getLayoutX() / 16)] == -1
                    || (mapbuff[((int) player.getLayoutY() / 16) - 1][(int) (player.getLayoutX() / 16)] == 210000)
                    || (mapbuff[((int) player.getLayoutY() / 16) - 1][(int) (player.getLayoutX() / 16)] == 240)
                    || (mapbuff[((int) player.getLayoutY() / 16) - 1][(int) (player.getLayoutX() / 16)] == 23)) {
                player.setLayoutY(player.getLayoutY() - 16);
                bokoblin.setLayoutY(bokoblin.getLayoutY()- 16);
                player.setImage(pv.up());
            }
            else {
                player.setImage(pv.down());
            }
        }

        if ((event.getCode() == KeyCode.DOWN || event.getCode() == KeyCode.S)) {
            if (mapbuff[((int) player.getLayoutY() / 16) + 1][(int) (player.getLayoutX() / 16)] == -1
                    || (mapbuff[((int) player.getLayoutY() / 16) + 1][(int) (player.getLayoutX() / 16)] == 200000)
                    || (mapbuff[((int) player.getLayoutY() / 16) + 1][(int) (player.getLayoutX() / 16)] == 280)) {
                player.setLayoutY(player.getLayoutY() + 16);
                bokoblin.setLayoutY(bokoblin.getLayoutY() + 16);
                player.setImage(pv.down());
            }
            else {
                player.setImage(pv.up());
            }
        }

        if ((event.getCode() == KeyCode.LEFT || event.getCode() == KeyCode.Q)) {
            if (mapbuff[(int) (player.getLayoutY() / 16)][((int) (player.getLayoutX() / 16)) - 1] == -1
                    || (mapbuff[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16) - 1] == 230)
                    || (mapbuff[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16) -1] == 27)) {
                player.setLayoutX(player.getLayoutX() - 16);
                bokoblin.setLayoutX(bokoblin.getLayoutX() - 16);
                player.setImage(pv.left());
            }
            else {
                player.setImage(pv.right());
            }
        }

        if ((event.getCode() == KeyCode.RIGHT || event.getCode() == KeyCode.D)) {
            if (mapbuff[(int) (player.getLayoutY() / 16)][((int) (player.getLayoutX() / 16)) + 1] == -1
                    || (mapbuff[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16) + 1] == 220000)
                    || (mapbuff[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16) + 1] == 260)) {
                player.setLayoutX(player.getLayoutX() + 16);
                bokoblin.setLayoutX(bokoblin.getLayoutX() + 16);
                player.setImage(pv.right());
            }
            else {
                player.setImage(pv.left());
            }
        }


        if ((event.getCode() == KeyCode.ENTER)) {
            link.attack(bokoblinsword,sword);
            System.out.print("\n" + bokoblinsword.getHeart());
            if (!(bokoblinsword.isAlive())) {
                bokoblin.setImage(ve.isDead());
            }
        }

        if ((!(event.getCode() == KeyCode.Y)) && ((!(event.getCode() == KeyCode.ESCAPE))) && ((!(event.getCode() == KeyCode.N)))
           && ((!(event.getCode() == KeyCode.ENTER)))) {
            System.err.println("[!] Identifier of movement : " + mapbuff[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16)] + " [!] " + "\n-----------------------------------");
        }

        if (mapbuff[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16)] == 200000) {
            System.err.println("[!] Warning, you have changed map [!]" + "\n[!] Loading house to town [!]" + "\n[!] Identifier of the map change box : " + mapbuff[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16)] + " [!] ");

            tilePaneFX.getChildren().remove(mv.house());
            tilePaneFX.getChildren().add(mv.town());
            player.setLayoutX(272);
            player.setLayoutY(336);
            player.setImage(pv.down());

            town.initMap();
            copyField(town.getMap());

            for (int i = 0; i < town.getMap().length; i++) {
                for (int j = 0; j < town.getMap()[i].length; j++) {
                    System.out.print(town.getMap()[i][j] + ",");
                }
                System.out.println();
            }


        }

        if (mapbuff[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16)] == 210000) {
            System.err.println("[!] Warning, you have changed map [!]" + "\n[!] Loading house to town [!]" + "\n[!] Identifier of the map change box : " + mapbuff[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16)] + " [!] ");
            tilePaneFX.getChildren().remove(mv.town());
            tilePaneFX.getChildren().add(mv.house());
            player.setLayoutX(240);
            player.setLayoutY(464);
            player.setImage(pv.up());

            house.initMap();
            copyField(house.getMap());
            for (int i = 0; i < house.getMap().length; i++) {
                for (int j = 0; j < house.getMap()[i].length; j++) {
                    System.out.print(house.getMap()[i][j] + ",");
                }
                System.out.println();
            }


        }

        if (mapbuff[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16)] == 220000) {
            System.err.println("[!] Warning, you have changed map [!]" + "\n[!] Loading town to plain [!]" + "\n[!] Identifier of the map change box : " + mapbuff[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16)] + " [!] ");

            tilePaneFX.getChildren().remove(mv.town());
            tilePaneFX.getChildren().add(mv.plain());
            player.setLayoutX(16);
            player.setLayoutY(322);
            player.setImage(pv.right());
            bokoblin.setImage(ve.up());
            bokoblin.setLayoutX(156);
            bokoblin.setLayoutY(322);

            plain.initMap();
            copyField(plain.getMap());

            for (int i = 0; i < plain.getMap().length; i++) {
                for (int j = 0; j < plain.getMap()[i].length; j++) {
                    System.out.print(plain.getMap()[i][j] + ",");
                }
                System.out.println();
            }


        }

        if (mapbuff[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16)] == 230) {
            System.err.println("[!] Warning, you have changed map [!]" + "\n[!] Loading plain to town [!]" + "\n[!] Identifier of the map change box : " + mapbuff[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16)] + " [!] ");

            tilePaneFX.getChildren().remove(mv.plain());
            tilePaneFX.getChildren().add(mv.town());
            player.setLayoutX(656);
            player.setLayoutY(176);
            player.setImage(pv.left());

            town.initMap();
            copyField(town.getMap());
            for (int i = 0; i < town.getMap().length; i++) {
                for (int j = 0; j < town.getMap()[i].length; j++) {
                    System.out.print(town.getMap()[i][j] + ",");
                }
                System.out.println();
            }


        }

        if (mapbuff[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16)] == 240) {
            System.err.println("[!] Warning, you have changed map [!]" + "\n[!] Loading plain to iceway [!]" + "\n[!] Identifier of the map change box : " + mapbuff[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16)] + " [!] ");

            tilePaneFX.getChildren().remove(mv.plain());
            tilePaneFX.getChildren().add(mv.iceway());
            player.setLayoutX(400);
            player.setLayoutY(560);
            player.setImage(pv.up());

            iceway.initMap();
            copyField(iceway.getMap());
            for (int i = 0; i < iceway.getMap().length; i++) {
                for (int j = 0; j < iceway.getMap()[i].length; j++) {
                    System.out.print(iceway.getMap()[i][j] + ",");
                }
                System.out.println();
            }


        }

        if (mapbuff[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16)] == 260) {
            System.err.println("[!] Warning, you have changed map [!]" + "\n[!] Loading plain to dirtway [!]" + "\n[!] Identifier of the map change box : " + mapbuff[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16)] + " [!] ");

            tilePaneFX.getChildren().remove(mv.plain());
            tilePaneFX.getChildren().add(mv.dirtway());
            player.setLayoutX(32);
            player.setLayoutY(176);
            player.setImage(pv.right());

            dirtway.initMap();
            copyField(dirtway.getMap());
            for (int i = 0; i < dirtway.getMap().length; i++) {
                for (int j = 0; j < dirtway.getMap()[i].length; j++) {
                    System.out.print(dirtway.getMap()[i][j] + ",");
                }
                System.out.println();
            }


        }

        if (mapbuff[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16)] == 280) {
            System.err.println("[!] Warning, you have changed map [!]" + "\n[!] Loading plain to fireway [!]" + "\n[!] Identifier of the map change box : " + mapbuff[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16)] + " [!] ");

            tilePaneFX.getChildren().remove(mv.plain());
            tilePaneFX.getChildren().add(mv.fireway());
            player.setLayoutX(272);
            player.setLayoutY(16);
            player.setImage(pv.down());

            fireway.initMap();
            copyField(fireway.getMap());
            for (int i = 0; i < fireway.getMap().length; i++) {
                for (int j = 0; j < fireway.getMap()[i].length; j++) {
                    System.out.print(fireway.getMap()[i][j] + ",");
                }
                System.out.println();
            }


        }

        if (mapbuff[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16)] == 23) {
            System.err.println("[!] Warning, you have changed map [!]" + "\n[!] Loading fireway to plain [!]" + "\n[!] Identifier of the map change box : " + mapbuff[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16)] + " [!] ");

            tilePaneFX.getChildren().remove(mv.fireway());
            tilePaneFX.getChildren().add(mv.plain());
            player.setLayoutX(452);
            player.setLayoutY(736);
            player.setImage(pv.up());

            plain.initMap();
            copyField(plain.getMap());

            for (int i = 0; i < plain.getMap().length; i++) {
                for (int j = 0; j < plain.getMap()[i].length; j++) {
                    System.out.print(plain.getMap()[i][j] + ",");
                }
                System.out.println();
            }
        }

        if (mapbuff[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16)] == 27) {
            System.err.println("[!] Warning, you have changed map [!]" + "\n[!] Loading dirtway to plain [!]" + "\n[!] Identifier of the map change box : " + mapbuff[((int) player.getLayoutY() / 16)][(int) (player.getLayoutX() / 16)] + " [!] ");

            tilePaneFX.getChildren().remove(mv.dirtway());
            tilePaneFX.getChildren().add(mv.plain());
            player.setLayoutX(960);
            player.setLayoutY(304);
            player.setImage(pv.left());

            plain.initMap();
            copyField(plain.getMap());

            for (int i = 0; i < plain.getMap().length; i++) {
                for (int j = 0; j < plain.getMap()[i].length; j++) {
                    System.out.print(plain.getMap()[i][j] + ",");
                }
                System.out.println();
            }
        }



        // Leave the game with KeyEvent //

        if (event.getCode() == KeyCode.ESCAPE && leavegamey) {
            leavegameescape = false;
        }

        if (event.getCode() == KeyCode.ESCAPE && !leavegamey) {
            leavegameescape = true;
            System.err.println("[!] You will leave the game, are you sure (y/n) ? [!]");
        }

        if (event.getCode() == KeyCode.Y && leavegameescape) {
            leavegamey = true;
        }

        if (event.getCode() == KeyCode.Y && !leavegameescape) {
            leavegamey = false;
        }

        if (event.getCode() == KeyCode.N) {
            leavegameescape = false;
            leavegamey = false;
        }

        if ((leavegameescape && leavegamey)) {
            System.err.println("[!] See you soon [!]");
            System.exit(0);
        }
    }

    public void initialize(URL location, ResourceBundle resources) {
        house.initMap();

        mapbuff = house.getMap();
        tilePaneFX.getChildren().add(mv.house());
        player.setImage(pv.down());
        player.setLayoutX(220);
        player.setLayoutY(176);
        player.setFocusTraversable(true);
      //  bokoblin.translateXProperty().bind(bokoblinsword.getX());
        for (int i = 0; i < mapbuff.length; i++) {
            for (int j = 0; j < mapbuff[i].length; j++) {
                System.out.print(mapbuff[i][j] + ",");
            }
            System.out.println();
        }
    }

    public void copyField(int[][] source) {
        mapbuff = new int[source.length][source[0].length];
        for (int i = 0; i < source.length; i++) {
            for (int j = 0; j < source[i].length; j++) {
                mapbuff[i][j] = source[i][j];
            }
        }
        System.out.println("Length of the loaded map : " + source.length + "\nHeight of the loaded map : " + source[0].length);
    }
}
